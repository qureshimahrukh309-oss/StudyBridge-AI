import React, { useState, useEffect } from 'react';
import { useAuth, AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { AuthPage } from './components/auth/AuthPage';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { Dashboard } from './components/dashboard/Dashboard';
import { CourseList } from './components/courses/CourseList';
import { TaskList } from './components/tasks/TaskList';
import { NotesAndChat } from './components/notes/NotesAndChat';
import { StudyPlanner } from './components/planner/StudyPlanner';

import { Course, Task, Note, StudyPlan } from './types';
import { 
  INITIAL_DEMO_COURSES, 
  INITIAL_DEMO_TASKS, 
  INITIAL_DEMO_NOTES, 
  INITIAL_DEMO_STUDY_PLAN 
} from './lib/demoData';

import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc 
} from 'firebase/firestore';
import { db } from './lib/firebase';
import { Loader2 } from 'lucide-react';

function MainAppContent() {
  const { user, loading, isDemoUser } = useAuth();

  // Navigation State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Modals Trigger State
  const [isAddCourseModalOpen, setIsAddCourseModalOpen] = useState(false);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);

  // Data Collections State
  const [courses, setCourses] = useState<Course[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [plans, setPlans] = useState<StudyPlan[]>([]);

  // Sync state with Firestore or Demo Data
  useEffect(() => {
    if (isDemoUser) {
      setCourses(INITIAL_DEMO_COURSES);
      setTasks(INITIAL_DEMO_TASKS);
      setNotes(INITIAL_DEMO_NOTES);
      setPlans([INITIAL_DEMO_STUDY_PLAN]);
      return;
    }

    if (!user) {
      setCourses([]);
      setTasks([]);
      setNotes([]);
      setPlans([]);
      return;
    }

    // Subscribe to Firestore collections
    const coursesQ = query(collection(db, 'courses'), where('userId', '==', user.uid));
    const unsubCourses = onSnapshot(coursesQ, (snap) => {
      const items: Course[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Course));
      setCourses(items);
    }, (err) => console.warn('Firestore courses sub err:', err));

    const tasksQ = query(collection(db, 'tasks'), where('userId', '==', user.uid));
    const unsubTasks = onSnapshot(tasksQ, (snap) => {
      const items: Task[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Task));
      setTasks(items);
    }, (err) => console.warn('Firestore tasks sub err:', err));

    const notesQ = query(collection(db, 'notes'), where('userId', '==', user.uid));
    const unsubNotes = onSnapshot(notesQ, (snap) => {
      const items: Note[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Note));
      setNotes(items);
    }, (err) => console.warn('Firestore notes sub err:', err));

    const plansQ = query(collection(db, 'studyPlans'), where('userId', '==', user.uid));
    const unsubPlans = onSnapshot(plansQ, (snap) => {
      const items: StudyPlan[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as StudyPlan));
      setPlans(items);
    }, (err) => console.warn('Firestore plans sub err:', err));

    return () => {
      unsubCourses();
      unsubTasks();
      unsubNotes();
      unsubPlans();
    };
  }, [user, isDemoUser]);

  // Loading Screen
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin mb-3" />
        <p className="text-xs font-semibold text-slate-600 dark:text-slate-400">
          Loading StudyBridge AI...
        </p>
      </div>
    );
  }

  // Auth Screen fallback (Guest Mode enabled by default for all users)
  const activeUser = user || {
    uid: 'demo_user_123',
    email: 'alex.student@studybridge.ai',
    displayName: 'Alex Morgan',
    photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
  };

  // --- COURSE ACTIONS ---
  const handleAddCourse = async (newCourse: Omit<Course, 'id'>) => {
    if (isDemoUser) {
      const item: Course = { ...newCourse, id: `course_${Date.now()}` };
      setCourses(prev => [item, ...prev]);
      return;
    }
    if (!user) return;
    await addDoc(collection(db, 'courses'), {
      ...newCourse,
      userId: user.uid,
      createdAt: new Date().toISOString()
    });
  };

  const handleUpdateCourse = async (id: string, updated: Partial<Course>) => {
    if (isDemoUser) {
      setCourses(prev => prev.map(c => c.id === id ? { ...c, ...updated } : c));
      return;
    }
    await updateDoc(doc(db, 'courses', id), updated);
  };

  const handleDeleteCourse = async (id: string) => {
    if (isDemoUser) {
      setCourses(prev => prev.filter(c => c.id !== id));
      return;
    }
    await deleteDoc(doc(db, 'courses', id));
  };

  // --- TASK ACTIONS ---
  const handleAddTask = async (newTask: Omit<Task, 'id'>) => {
    if (isDemoUser) {
      const item: Task = { ...newTask, id: `task_${Date.now()}` };
      setTasks(prev => [item, ...prev]);
      return;
    }
    if (!user) return;
    await addDoc(collection(db, 'tasks'), {
      ...newTask,
      userId: user.uid,
      createdAt: new Date().toISOString()
    });
  };

  const handleUpdateTask = async (id: string, updated: Partial<Task>) => {
    if (isDemoUser) {
      setTasks(prev => prev.map(t => t.id === id ? { ...t, ...updated } : t));
      return;
    }
    await updateDoc(doc(db, 'tasks', id), updated);
  };

  const handleDeleteTask = async (id: string) => {
    if (isDemoUser) {
      setTasks(prev => prev.filter(t => t.id !== id));
      return;
    }
    await deleteDoc(doc(db, 'tasks', id));
  };

  const handleToggleTask = async (id: string) => {
    const target = tasks.find(t => t.id === id);
    if (!target) return;
    const newStatus = target.status === 'completed' ? 'todo' : 'completed';
    await handleUpdateTask(id, { status: newStatus });
  };

  // --- NOTE ACTIONS ---
  const handleAddNote = async (newNote: Omit<Note, 'id'>) => {
    if (isDemoUser) {
      const item: Note = { ...newNote, id: `note_${Date.now()}` };
      setNotes(prev => [item, ...prev]);
      return item;
    }
    const uid = user ? user.uid : 'demo_user_123';
    const docRef = await addDoc(collection(db, 'notes'), {
      ...newNote,
      userId: uid,
      createdAt: new Date().toISOString()
    });
    const item: Note = { ...newNote, id: docRef.id, userId: uid };
    setNotes(prev => [item, ...prev]);
    return item;
  };

  const handleDeleteNote = async (id: string) => {
    if (isDemoUser) {
      setNotes(prev => prev.filter(n => n.id !== id));
      return;
    }
    await deleteDoc(doc(db, 'notes', id));
  };

  // --- PLAN ACTIONS ---
  const handleAddPlan = async (newPlan: Omit<StudyPlan, 'id'>) => {
    if (isDemoUser) {
      const item: StudyPlan = { ...newPlan, id: `plan_${Date.now()}` };
      setPlans(prev => [item, ...prev]);
      return;
    }
    if (!user) return;
    await addDoc(collection(db, 'studyPlans'), {
      ...newPlan,
      userId: user.uid,
      createdAt: new Date().toISOString()
    });
  };

  const handleDeletePlan = async (id: string) => {
    if (isDemoUser) {
      setPlans(prev => prev.filter(p => p.id !== id));
      return;
    }
    await deleteDoc(doc(db, 'studyPlans', id));
  };

  // Counts helpers
  const tasksCountByCourse: Record<string, number> = {};
  tasks.forEach(t => {
    tasksCountByCourse[t.courseId] = (tasksCountByCourse[t.courseId] || 0) + 1;
  });

  const notesCountByCourse: Record<string, number> = {};
  notes.forEach(n => {
    notesCountByCourse[n.courseId] = (notesCountByCourse[n.courseId] || 0) + 1;
  });

  const pendingTasksCount = tasks.filter(t => t.status !== 'completed').length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors">
      
      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        onToggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
      />

      {/* Body Layout */}
      <div className="flex flex-1 max-w-7xl w-full mx-auto">
        
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
          pendingTasksCount={pendingTasksCount}
          coursesCount={courses.length}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
          {activeTab === 'dashboard' && (
            <Dashboard
              courses={courses}
              tasks={tasks}
              notes={notes}
              plans={plans}
              onNavigate={setActiveTab}
              onTaskToggle={handleToggleTask}
              onOpenAddCourse={() => { setActiveTab('courses'); setIsAddCourseModalOpen(true); }}
              onOpenAddTask={() => { setActiveTab('tasks'); setIsAddTaskModalOpen(true); }}
            />
          )}

          {activeTab === 'courses' && (
            <CourseList
              courses={courses}
              onAddCourse={handleAddCourse}
              onUpdateCourse={handleUpdateCourse}
              onDeleteCourse={handleDeleteCourse}
              tasksCountByCourse={tasksCountByCourse}
              notesCountByCourse={notesCountByCourse}
              isAddModalOpen={isAddCourseModalOpen}
              setIsAddModalOpen={setIsAddCourseModalOpen}
            />
          )}

          {activeTab === 'tasks' && (
            <TaskList
              tasks={tasks}
              courses={courses}
              onAddTask={handleAddTask}
              onUpdateTask={handleUpdateTask}
              onDeleteTask={handleDeleteTask}
              onToggleTask={handleToggleTask}
              isAddModalOpen={isAddTaskModalOpen}
              setIsAddModalOpen={setIsAddTaskModalOpen}
            />
          )}

          {activeTab === 'notes' && (
            <NotesAndChat
              notes={notes}
              courses={courses}
              onAddNote={handleAddNote}
              onDeleteNote={handleDeleteNote}
            />
          )}

          {activeTab === 'planner' && (
            <StudyPlanner
              plans={plans}
              courses={courses}
              onAddPlan={handleAddPlan}
              onDeletePlan={handleDeletePlan}
            />
          )}
        </main>

      </div>

    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <MainAppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
