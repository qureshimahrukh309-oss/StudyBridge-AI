import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { 
  GraduationCap, 
  Sun, 
  Moon, 
  LogOut, 
  Sparkles, 
  Github, 
  User as UserIcon,
  Menu,
  LogIn,
  X
} from 'lucide-react';
import { DeploymentGuideModal } from '../github/DeploymentGuideModal';
import { AuthPage } from '../auth/AuthPage';

interface Props {
  activeTab: string;
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<Props> = ({ activeTab, onToggleSidebar }) => {
  const { user, isDemoUser, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [guideOpen, setGuideOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const getPageTitle = (tab: string) => {
    switch (tab) {
      case 'dashboard': return 'Dashboard Overview';
      case 'courses': return 'Course Management';
      case 'tasks': return 'Study Task Tracker';
      case 'notes': return 'Notes & AI Study Chat';
      case 'planner': return 'AI Smart Study Planner';
      default: return 'StudyBridge AI';
    }
  };

  return (
    <>
      <header className="sticky top-0 z-30 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 px-4 sm:px-6 transition-colors">
        <div className="flex items-center justify-between h-full max-w-7xl mx-auto">
          
          {/* Left: Mobile menu toggle + Brand Title */}
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
              aria-label="Toggle menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div className="hidden sm:block">
                <span className="font-bold text-slate-900 dark:text-white tracking-tight text-base flex items-center gap-1.5">
                  StudyBridge <span className="text-blue-600 dark:text-blue-400 font-extrabold text-xs px-1.5 py-0.5 rounded-md bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60">AI</span>
                </span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 -mt-0.5 font-medium">
                  {getPageTitle(activeTab)}
                </p>
              </div>
            </div>
          </div>

          {/* Right: Deployment guide button, Dark Mode Toggle, Profile & Logout */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Deployment Guide Trigger */}
            <button
              onClick={() => setGuideOpen(true)}
              className="hidden md:flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors border border-slate-200/80 dark:border-slate-700/80"
              title="Deployment & Export Guide"
            >
              <Github className="w-4 h-4 text-slate-900 dark:text-white" />
              <span>GitHub / Vercel</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
              aria-label="Toggle Dark Mode"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-amber-400" />
              ) : (
                <Moon className="w-5 h-5 text-slate-600" />
              )}
            </button>

            {/* Demo Mode Badge / Login Trigger */}
            {isDemoUser ? (
              <button
                onClick={() => setAuthModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-purple-700 dark:text-purple-300 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/60 dark:hover:bg-purple-900/60 border border-purple-200 dark:border-purple-800 rounded-xl transition-colors"
                title="Guest Mode active. Click to Sign In or Create Account"
              >
                <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                <span>Guest Mode (Sign In)</span>
              </button>
            ) : null}

            {/* User Avatar & Logout */}
            {user && (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
                <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center overflow-hidden border border-slate-300 dark:border-slate-600">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || 'User'} className="w-full h-full object-cover" />
                  ) : (
                    <UserIcon className="w-4 h-4 text-slate-600 dark:text-slate-300" />
                  )}
                </div>
                <div className="hidden lg:block text-left">
                  <p className="text-xs font-semibold text-slate-900 dark:text-white truncate max-w-[120px]">
                    {user.displayName || 'Student'}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[120px]">
                    {user.email || 'Online'}
                  </p>
                </div>
                <button
                  onClick={logout}
                  className="p-2 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors ml-1"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}

          </div>

        </div>
      </header>

      {/* Deployment Guide Modal */}
      <DeploymentGuideModal isOpen={guideOpen} onClose={() => setGuideOpen(false)} />

      {/* Auth Modal when in Guest Mode */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative w-full max-w-md my-8">
            <button
              onClick={() => setAuthModalOpen(false)}
              className="absolute top-4 right-4 z-10 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 bg-white/80 dark:bg-slate-800/80 rounded-full backdrop-blur-sm transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <AuthPage onClose={() => setAuthModalOpen(false)} />
          </div>
        </div>
      )}
    </>
  );
};
