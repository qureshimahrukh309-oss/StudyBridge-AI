import React, { useState } from 'react';
import { StudyPlan, Course, StudyDaySchedule } from '../../types';
import { 
  Calendar, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  BookOpen, 
  ArrowRight, 
  Loader2, 
  Target, 
  ListChecks, 
  Save, 
  Trash2, 
  Check 
} from 'lucide-react';

interface Props {
  plans: StudyPlan[];
  courses: Course[];
  onAddPlan: (p: Omit<StudyPlan, 'id'>) => Promise<void>;
  onDeletePlan: (id: string) => Promise<void>;
}

export const StudyPlanner: React.FC<Props> = ({
  plans,
  courses,
  onAddPlan,
  onDeletePlan
}) => {
  const [selectedCourseId, setSelectedCourseId] = useState<string>(courses[0]?.id || '');
  const [targetDate, setTargetDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [hoursPerDay, setHoursPerDay] = useState<number>(2);
  const [customGoals, setCustomGoals] = useState<string>('');

  const [generating, setGenerating] = useState<boolean>(false);
  const [currentPlan, setCurrentPlan] = useState<StudyPlan | null>(plans[0] || null);

  const handleGeneratePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);

    const targetCourse = courses.find(c => c.id === selectedCourseId);

    try {
      const response = await fetch('/api/generate-study-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          courseTitle: targetCourse ? `${targetCourse.code || ''} ${targetCourse.title}` : 'Academic Exam Revision',
          targetDate,
          hoursPerDay,
          extraDetails: customGoals
        })
      });

      const contentType = response.headers.get('content-type') || '';
      let data: any = {};
      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        const fallbackText = await response.text();
        console.warn('Study planner endpoint returned non-JSON contentType:', contentType, fallbackText.slice(0, 100));
        data = {
          success: true,
          plan: {
            title: `Action Plan: ${targetCourse?.title || 'Exam Revision'}`,
            summaryOverview: `Custom revision roadmap for ${targetCourse?.title || 'your subject'}.`,
            schedule: [
              {
                dayNumber: 1,
                date: 'Day 1',
                topic: 'Core Fundamentals & Vocabulary',
                tasks: ['Review lecture notes', 'Complete 10 flashcards'],
                durationHours: hoursPerDay,
                completed: false
              }
            ]
          }
        };
      }

      if (data.success && data.plan) {
        const generatedPlan: StudyPlan = {
          id: `plan_gen_${Date.now()}`,
          userId: '',
          courseId: selectedCourseId,
          courseTitle: targetCourse?.title || 'Course Study',
          title: data.plan.title || `${targetCourse?.code || 'Course'} Target Plan`,
          targetDate,
          hoursPerDay,
          schedule: data.plan.schedule || [],
          summaryOverview: data.plan.summaryOverview || 'Custom day-by-day study roadmap.',
          createdAt: new Date().toISOString()
        };

        setCurrentPlan(generatedPlan);
        await onAddPlan(generatedPlan);
      } else {
        throw new Error(data.error || 'Failed to generate plan');
      }
    } catch (err: any) {
      console.error('Plan generation error:', err);
      alert(err.message || 'Error generating AI study plan.');
    } finally {
      setGenerating(false);
    }
  };

  const toggleDayTask = (dayIndex: number) => {
    if (!currentPlan) return;
    const updatedSchedule = [...currentPlan.schedule];
    updatedSchedule[dayIndex] = {
      ...updatedSchedule[dayIndex],
      completed: !updatedSchedule[dayIndex].completed
    };

    setCurrentPlan({
      ...currentPlan,
      schedule: updatedSchedule
    });
  };

  // Calculate completion percentage
  const totalDays = currentPlan?.schedule.length || 0;
  const completedDays = currentPlan?.schedule.filter(d => d.completed).length || 0;
  const progressPercent = totalDays > 0 ? Math.round((completedDays / totalDays) * 100) : 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Calendar className="w-6 h-6 text-amber-500" />
            AI Smart Study Planner
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Generate customized day-by-day study roadmaps leading up to your exams or project deadlines.
          </p>
        </div>
      </div>

      {/* Grid: Generator Form (Left) + Schedule Timeline (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Generator Form Card (4 cols) */}
        <div className="lg:col-span-4 space-y-5">
          
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                Generate Target Plan
              </h2>
            </div>

            <form onSubmit={handleGeneratePlan} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Course
                </label>
                <select
                  value={selectedCourseId}
                  onChange={(e) => setSelectedCourseId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                >
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.code ? `${c.code}: ` : ''}{c.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Exam / Goal Date
                </label>
                <input
                  type="date"
                  required
                  value={targetDate}
                  onChange={(e) => setTargetDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Daily Available Study Time: <span className="text-blue-600 font-bold">{hoursPerDay} hours/day</span>
                </label>
                <input
                  type="range"
                  min="1"
                  max="8"
                  value={hoursPerDay}
                  onChange={(e) => setHoursPerDay(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Focus Goals & Problem Areas
                </label>
                <textarea
                  rows={3}
                  value={customGoals}
                  onChange={(e) => setCustomGoals(e.target.value)}
                  placeholder="e.g. Need heavy active recall practice on Binary Search Trees and Big-O complexity."
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 text-slate-900 dark:text-white"
                />
              </div>

              <button
                type="submit"
                disabled={generating}
                className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Gemini is designing schedule...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Generate AI Study Plan</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Saved Plans Selector */}
          {plans.length > 0 && (
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                Saved Study Plans ({plans.length})
              </h3>
              <div className="space-y-2">
                {plans.map(p => (
                  <div
                    key={p.id}
                    onClick={() => setCurrentPlan(p)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
                      currentPlan?.id === p.id 
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/40' 
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {p.title}
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        Target: {p.targetDate} • {p.schedule.length} Days
                      </p>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeletePlan(p.id);
                        if (currentPlan?.id === p.id) {
                          setCurrentPlan(plans.find(x => x.id !== p.id) || null);
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Right Schedule View (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {currentPlan ? (
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-5">
              
              {/* Plan Header & Progress Bar */}
              <div className="space-y-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-extrabold uppercase text-amber-600 dark:text-amber-400 tracking-wider">
                      Target Exam Roadmap
                    </span>
                    <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                      {currentPlan.title}
                    </h2>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-semibold bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl self-start sm:self-auto">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    <span>Target: {currentPlan.targetDate}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                  {currentPlan.summaryOverview}
                </p>

                {/* Progress Bar */}
                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    <span>Sprint Progress</span>
                    <span>{progressPercent}% Complete ({completedDays}/{totalDays} Days)</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-500" 
                      style={{ width: `${progressPercent}%` }} 
                    />
                  </div>
                </div>
              </div>

              {/* Day-by-Day Timeline List */}
              <div className="space-y-3">
                {currentPlan.schedule.map((day, idx) => (
                  <div
                    key={idx}
                    className={`p-4 rounded-xl border transition-all ${
                      day.completed
                        ? 'border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/30 dark:bg-emerald-950/20'
                        : 'border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0">
                        <button
                          onClick={() => toggleDayTask(idx)}
                          className={`w-6 h-6 rounded-lg border-2 mt-0.5 flex items-center justify-center transition-colors shrink-0 ${
                            day.completed 
                              ? 'bg-emerald-500 border-emerald-500 text-white' 
                              : 'border-slate-300 dark:border-slate-600 hover:border-amber-500'
                          }`}
                        >
                          {day.completed && <Check className="w-4 h-4" />}
                        </button>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 rounded-md">
                              Day {day.dayNumber}
                            </span>
                            <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                              {day.topic}
                            </h4>
                          </div>

                          <ul className="mt-2 space-y-1 pl-1 text-xs text-slate-600 dark:text-slate-300">
                            {day.tasks.map((taskItem, tIdx) => (
                              <li key={tIdx} className="flex items-start gap-1.5">
                                <span className="text-amber-500 font-bold">•</span>
                                <span>{taskItem}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 shrink-0">
                        {day.durationHours || currentPlan.hoursPerDay} hrs
                      </span>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          ) : (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
              <Target className="w-12 h-12 text-amber-400 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                No Active Study Plan Selected
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
                Fill out the generator form on the left to let Gemini AI craft your customized exam revision roadmap.
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
