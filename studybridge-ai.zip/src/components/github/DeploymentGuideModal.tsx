import React, { useState } from 'react';
import { X, Github, ExternalLink, Copy, Check, Terminal, Shield, Rocket } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const DeploymentGuideModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const gitCommands = `# 1. Initialize Git repository and commit files
git init
git add .
git commit -m "Initial commit of StudyBridge AI"

# 2. Add your GitHub repository remote
git remote add origin https://github.com/YOUR_USERNAME/studybridge-ai.git
git branch -M main
git push -u origin main`;

  const vercelBuildSettings = `{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite"
}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 rounded-xl">
              <Rocket className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                GitHub & Vercel Deployment Guide
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                How to export, push to GitHub, and deploy StudyBridge AI to production
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Steps Content */}
        <div className="space-y-6 text-slate-700 dark:text-slate-300 text-sm">
          
          {/* Step 1: Export & Push to GitHub */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <Github className="w-4 h-4 text-slate-900 dark:text-white" />
                Step 1: Push Code to GitHub
              </h3>
              <button
                onClick={() => copyToClipboard(gitCommands, 'git')}
                className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium"
              >
                {copied === 'git' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                {copied === 'git' ? 'Copied Commands!' : 'Copy Terminal Script'}
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto leading-relaxed">
              {gitCommands}
            </pre>
          </div>

          {/* Step 2: Environment Variables */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
            <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2 mb-2">
              <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              Step 2: Environment Variables Setup
            </h3>
            <p className="mb-3 text-xs text-slate-600 dark:text-slate-400">
              When deploying to Vercel or running locally, add the following key environment variables:
            </p>
            <div className="space-y-2 font-mono text-xs">
              <div className="p-2.5 bg-slate-900 text-slate-200 rounded-lg flex items-center justify-between">
                <span>GEMINI_API_KEY=your_gemini_api_key_here</span>
                <span className="text-[10px] text-amber-400 font-sans px-2 py-0.5 bg-amber-950/60 rounded">Required for AI</span>
              </div>
            </div>
          </div>

          {/* Step 3: Vercel Deployment */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                Step 3: Import & Deploy on Vercel
              </h3>
              <a
                href="https://vercel.com/new"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium"
              >
                Open Vercel Dashboard <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
              <li>Log in to <strong className="text-slate-900 dark:text-white">Vercel.com</strong> and click <strong className="text-slate-900 dark:text-white">Add New &gt; Project</strong>.</li>
              <li>Select your <strong className="text-slate-900 dark:text-white">GitHub repository</strong> and click <strong className="text-slate-900 dark:text-white">Import</strong>.</li>
              <li>Set Framework Preset to <strong className="text-slate-900 dark:text-white">Vite</strong>.</li>
              <li>Add Environment Variable: <code className="text-blue-600 dark:text-blue-400 font-bold">GEMINI_API_KEY</code>.</li>
              <li>Click <strong className="text-slate-900 dark:text-white">Deploy</strong>. Your application will be live in seconds!</li>
            </ol>
          </div>

        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm rounded-xl transition-colors shadow-md"
          >
            Got it, thanks!
          </button>
        </div>

      </div>
    </div>
  );
};
