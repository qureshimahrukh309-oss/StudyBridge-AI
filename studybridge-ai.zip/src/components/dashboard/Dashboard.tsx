import React from 'react';
import { Course, Task, Note, StudyPlan } from '../../types';
import { 
  BookOpen, 
  CheckSquare, 
  FileText, 
  Calendar, 
  Sparkles, 
  Plus, 
  ArrowRight, 
  Clock, 
  CheckCircle2, 
  TrendingUp,
  BrainCircuit,
  AlertCircle
} from 'lucide-react';

interface Props {
  courses: Course[];
  tasks: Task[];
  notes: Note[];
  plans: StudyPlan[];
  onNavigate: (tab: string) => void;
  onTaskToggle: (taskId: string) => void;
  onOpenAddCourse: () => void;
  onOpenAddTask: () => void;
}

export const Dashboard: React.FC<Props> = ({
  courses,
  tasks,
  notes,
  plans,
  onNavigate,
  onTaskToggle,
  onOpenAddCourse,
  onOpenAddTask
}) => {
  const completedTasksCount = tasks.filter(t => t.status === 'completed').length;
  const pendingTasks = tasks.filter(t => t.status !== 'completed');
  const taskCompletionRate = tasks.length > 0 ? Math.round((completedTasksCount / tasks.length) * 100) : 0;

  // Priority tasks sorted by due date
  const urgentTasks = [...pendingTasks].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()).slice(0, 4);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Welcome Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI-Enhanced Study Workspace</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Ready to master your courses today?
          </h1>
          <p className="mt-2 text-sm text-blue-100 font-medium leading-relaxed">
            Upload notes for AI instant Q&A, generate target exam schedules, and keep your assignments strictly on track.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigate('notes')}
              className="px-4 py-2.5 bg-white hover:bg-blue-50 text-blue-700 text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-2"
            >
              <BrainCircuit className="w-4 h-4 text-blue-600" />
              <span>Ask AI About Notes</span>
            </button>
            <button
              onClick={() => onNavigate('planner')}
              className="px-4 py-2.5 bg-blue-500/30 hover:bg-blue-500/40 text-white border border-white/30 text-xs font-bold rounded-xl backdrop-blur-md transition-all flex items-center gap-2"
            >
              <Calendar className="w-4 h-4" />
              <span>Create AI Study Plan</span>
            </button>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: Courses */}
        <div 
          onClick={() => onNavigate('courses')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Enrolled Courses</span>
            <div className="p-2.5 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 rounded-xl group-hover:scale-110 transition-transform">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{courses.length}</p>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <span>Manage schedules & instructors</span>
          </p>
        </div>

        {/* Metric 2: Tasks Progress */}
        <div 
          onClick={() => onNavigate('tasks')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Tasks Completed</span>
            <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-xl group-hover:scale-110 transition-transform">
              <CheckSquare className="w-5 h-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">
            {completedTasksCount} <span className="text-sm font-normal text-slate-400">/ {tasks.length}</span>
          </p>
          <div className="mt-2 w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-500 h-full transition-all duration-500" 
              style={{ width: `${taskCompletionRate}%` }} 
            />
          </div>
        </div>

        {/* Metric 3: Uploaded Notes */}
        <div 
          onClick={() => onNavigate('notes')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Notes & PDF Docs</span>
            <div className="p-2.5 bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 rounded-xl group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{notes.length}</p>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <span>Ready for Gemini AI Q&A</span>
          </p>
        </div>

        {/* Metric 4: AI Study Plans */}
        <div 
          onClick={() => onNavigate('planner')}
          className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Active Study Plans</span>
            <div className="p-2.5 bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-xl group-hover:scale-110 transition-transform">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-white">{plans.length}</p>
          <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <span>Structured daily milestones</span>
          </p>
        </div>

      </div>

      {/* Main Grid: Urgent Tasks + Courses Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Columns: Urgent Tasks & Deadlines */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Upcoming Due Dates & Tasks
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenAddTask}
                  className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-lg text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" /> Add Task
                </button>
                <button
                  onClick={() => onNavigate('tasks')}
                  className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 font-semibold flex items-center gap-1"
                >
                  View All <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {urgentTasks.length === 0 ? (
              <div className="py-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  All caught up! No pending tasks due.
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Add new study tasks or generate a study plan.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {urgentTasks.map((task) => {
                  const course = courses.find(c => c.id === task.courseId);
                  const isHigh = task.priority === 'high';
                  return (
                    <div
                      key={task.id}
                      className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60 transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <button
                          onClick={() => onTaskToggle(task.id)}
                          className="w-5 h-5 rounded-md border-2 border-slate-300 dark:border-slate-600 hover:border-blue-500 flex items-center justify-center transition-colors shrink-0"
                        >
                          {task.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                        </button>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                            {task.title}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                            {course && (
                              <span className="font-medium text-slate-700 dark:text-slate-300">
                                {course.code || course.title}
                              </span>
                            )}
                            <span>• Due: {task.dueDate}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase ${
                          isHigh 
                            ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300' 
                            : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                        }`}>
                          {task.priority}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right 1 Column: Active Courses Quick Access */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                Active Courses
              </h2>
              <button
                onClick={onOpenAddCourse}
                className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-lg text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>

            {courses.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500 dark:text-slate-400">
                No courses added yet. Click Add to create your first course.
              </div>
            ) : (
              <div className="space-y-3">
                {courses.slice(0, 3).map((course) => {
                  const courseTasks = tasks.filter(t => t.courseId === course.id);
                  const completedCourseTasks = courseTasks.filter(t => t.status === 'completed').length;
                  return (
                    <div 
                      key={course.id}
                      onClick={() => onNavigate('courses')}
                      className="p-3.5 rounded-xl border border-slate-200/80 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 transition-all cursor-pointer bg-slate-50/50 dark:bg-slate-800/30"
                    >
                      <div className="flex items-center gap-2.5">
                        <div 
                          className="w-3 h-3 rounded-full shrink-0" 
                          style={{ backgroundColor: course.color || '#3B82F6' }} 
                        />
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {course.code ? `${course.code}: ` : ''}{course.title}
                        </p>
                      </div>
                      <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 pl-5">
                        {course.instructor || 'Instructor not set'} • {courseTasks.length} Tasks ({completedCourseTasks} done)
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
