import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  User as FirebaseUser, 
  onAuthStateChanged, 
  signInWithPopup, 
  signOut as firebaseSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { auth, googleProvider, db } from '../lib/firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { UserProfile } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  isDemoUser: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (e: string, p: string) => Promise<void>;
  signUpWithEmail: (e: string, p: string, name: string) => Promise<void>;
  enableDemoMode: () => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>({
    uid: 'demo_user_123',
    email: 'alex.student@studybridge.ai',
    displayName: 'Alex Morgan',
    photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [isDemoUser, setIsDemoUser] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        setIsDemoUser(false);
        const computedName = fbUser.displayName || fbUser.email?.split('@')[0] || 'Student';
        
        setUser(prev => {
          if (prev && prev.uid === fbUser.uid && prev.displayName && prev.displayName !== 'Student') {
            return prev;
          }
          return {
            uid: fbUser.uid,
            email: fbUser.email,
            displayName: computedName,
            photoURL: fbUser.photoURL,
          };
        });

        // Sync user profile document to Firestore
        try {
          const userRef = doc(db, 'users', fbUser.uid);
          const snap = await getDoc(userRef);
          if (!snap.exists()) {
            await setDoc(userRef, {
              uid: fbUser.uid,
              email: fbUser.email,
              displayName: computedName,
              photoURL: fbUser.photoURL || null,
              createdAt: new Date().toISOString()
            });
          }
        } catch (err) {
          console.warn('Firestore user doc sync warning:', err);
        }
      } else {
        // Default to guest student mode if no Firebase user logged in
        setIsDemoUser(true);
        setUser(prev => prev || {
          uid: 'demo_user_123',
          email: 'alex.student@studybridge.ai',
          displayName: 'Alex Morgan',
          photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
        });
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      if (res.user) {
        const profile: UserProfile = {
          uid: res.user.uid,
          email: res.user.email,
          displayName: res.user.displayName || 'Student',
          photoURL: res.user.photoURL,
        };
        setUser(profile);
      }
    } catch (error) {
      console.error('Google Sign In Error:', error);
      throw error;
    }
  };

  const signInWithEmail = async (email: string, _pass: string) => {
    setIsDemoUser(true);
    setUser({
      uid: 'user_' + Math.random().toString(36).substring(2, 9),
      email,
      displayName: email.split('@')[0] || 'Student',
      photoURL: null
    });
  };

  const signUpWithEmail = async (email: string, _pass: string, name: string) => {
    setIsDemoUser(true);
    const demoProfile: UserProfile = {
      uid: 'user_' + Math.random().toString(36).substring(2, 9),
      email,
      displayName: name || email.split('@')[0] || 'Student',
      photoURL: null
    };
    setUser(demoProfile);
  };

  const enableDemoMode = () => {
    setIsDemoUser(true);
    setUser({
      uid: 'demo_user_123',
      email: 'alex.student@studybridge.ai',
      displayName: 'Alex Morgan',
      photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
    });
    setLoading(false);
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth);
    } catch {
      // Ignore signOut error if not signed in via firebase
    }
    setIsDemoUser(true);
    setUser({
      uid: 'demo_user_123',
      email: 'alex.student@studybridge.ai',
      displayName: 'Alex Morgan',
      photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'
    });
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isDemoUser,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        enableDemoMode,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
