import { Course, Task, Note, StudyPlan } from '../types';

export const INITIAL_DEMO_COURSES: Course[] = [
  {
    id: 'course_cs101',
    userId: 'demo_user_123',
    title: 'Computer Science 101: Data Structures & Algorithms',
    code: 'CS101',
    instructor: 'Dr. Alan Turing',
    color: '#3B82F6', // blue
    schedule: 'Mon / Wed 10:00 AM - 11:30 AM',
    description: 'Fundamental study of arrays, linked lists, trees, graphs, sorting algorithms and asymptotic complexity analysis.',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10).toISOString()
  },
  {
    id: 'course_bio202',
    userId: 'demo_user_123',
    title: 'Cellular & Molecular Biology',
    code: 'BIO202',
    instructor: 'Prof. Rosalind Franklin',
    color: '#10B981', // emerald
    schedule: 'Tue / Thu 1:00 PM - 2:30 PM',
    description: 'Mechanisms of cellular replication, gene expression, protein synthesis, and metabolic pathways.',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString()
  },
  {
    id: 'course_math301',
    userId: 'demo_user_123',
    title: 'Linear Algebra & Matrix Calculus',
    code: 'MATH301',
    instructor: 'Dr. Carl Friedrich Gauss',
    color: '#8B5CF6', // purple
    schedule: 'Fri 9:00 AM - 12:00 PM',
    description: 'Vector spaces, matrix transformations, eigenvalues, eigenvectors, and singular value decomposition.',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString()
  }
];

export const INITIAL_DEMO_TASKS: Task[] = [
  {
    id: 'task_1',
    userId: 'demo_user_123',
    courseId: 'course_cs101',
    title: 'Implement Binary Search Tree in TypeScript',
    dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2).toISOString().split('T')[0],
    priority: 'high',
    status: 'in-progress',
    description: 'Write insert, delete, search, and in-order traversal methods. Test with edge cases.',
    createdAt: new Date().toISOString()
  },
  {
    id: 'task_2',
    userId: 'demo_user_123',
    courseId: 'course_bio202',
    title: 'Read Chapter 4: ATP Synthesis Pathways',
    dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 4).toISOString().split('T')[0],
    priority: 'medium',
    status: 'todo',
    description: 'Summarize electron transport chain key steps and write key terms in study notes.',
    createdAt: new Date().toISOString()
  },
  {
    id: 'task_3',
    userId: 'demo_user_123',
    courseId: 'course_math301',
    title: 'Eigenvalues Problem Set 3',
    dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 1).toISOString().split('T')[0],
    priority: 'high',
    status: 'todo',
    description: 'Solve matrix diagonalization problems 1 through 8.',
    createdAt: new Date().toISOString()
  },
  {
    id: 'task_4',
    userId: 'demo_user_123',
    courseId: 'course_cs101',
    title: 'Review Big-O Complexity Cheat Sheet',
    dueDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 1).toISOString().split('T')[0],
    priority: 'low',
    status: 'completed',
    description: 'Memorize time & space complexities for QuickSort, MergeSort, and HeapSort.',
    createdAt: new Date().toISOString()
  }
];

export const INITIAL_DEMO_NOTES: Note[] = [
  {
    id: 'note_1',
    userId: 'demo_user_123',
    courseId: 'course_cs101',
    title: 'Data Structures Midterm Study Notes.pdf',
    fileName: 'Data_Structures_Midterm_Notes.pdf',
    fileSize: 1024 * 450, // 450 KB
    summary: 'Comprehensive breakdown of linear and non-linear data structures. Covers Big-O notation, Array vs LinkedList tradeoffs, Hash Collisions resolution strategies (Chaining vs Open Addressing), and Balanced Tree rotations.',
    keyTerms: [
      'Big-O Notation: Upper bound worst-case execution time analysis.',
      'Hash Table: Key-value map using hash functions with average O(1) lookups.',
      'Binary Search Tree: Node structure where left < parent <= right.',
      'Amortized Time: Average time per operation over a sequence of operations.'
    ],
    extractedText: `Data Structures & Algorithms Core Review

1. Big-O Complexity Analysis:
- Array Lookup: O(1)
- Array Insertion / Deletion: O(n) average
- Hash Map Lookup/Insert: O(1) average, O(n) worst-case
- Binary Search Tree Lookup: O(log n) average, O(n) worst-case if unbalanced
- AVL / Red-Black Tree Lookup: Guaranteed O(log n)

2. Hash Table Collision Resolution:
a) Separate Chaining: Each bucket holds a linked list or dynamic array of colliding items.
b) Open Addressing: Probing sequential slots (Linear Probing, Quadratic Probing, Double Hashing).

3. Tree Traversals:
- Pre-Order: Root -> Left -> Right
- In-Order: Left -> Root -> Right (Produces sorted order in BST!)
- Post-Order: Left -> Right -> Root
- Breadth-First (BFS): Queue-based level-order traversal.`,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString()
  }
];

export const INITIAL_DEMO_STUDY_PLAN: StudyPlan = {
  id: 'plan_1',
  userId: 'demo_user_123',
  courseId: 'course_cs101',
  courseTitle: 'Computer Science 101',
  title: 'CS101 Midterm Sprint Strategy',
  targetDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 6).toISOString().split('T')[0],
  hoursPerDay: 2,
  summaryOverview: 'A focused 5-day study plan covering Big-O complexity, Hash Tables, Trees, and Graph algorithms with active recall practice.',
  schedule: [
    {
      dayNumber: 1,
      date: 'Day 1',
      topic: 'Big-O Analysis & Array vs Linked List Tradeoffs',
      tasks: [
        'Review asymptotic growth rates (O(1), O(log n), O(n), O(n log n), O(n^2))',
        'Solve 3 practice problems deriving worst-case time complexity',
        'Compare memory layout of contiguous arrays vs pointers in LinkedLists'
      ],
      durationHours: 2,
      completed: true
    },
    {
      dayNumber: 2,
      date: 'Day 2',
      topic: 'Stacks, Queues & Hash Maps',
      tasks: [
        'Implement Stack using Array and Queue using LinkedList',
        'Study Hash Function uniform distribution criteria',
        'Review collision resolution strategies (Chaining vs Open Addressing)'
      ],
      durationHours: 2,
      completed: true
    },
    {
      dayNumber: 3,
      date: 'Day 3',
      topic: 'Binary Search Trees & Rotations',
      tasks: [
        'Practice manual tree insertions and deletions on paper',
        'Implement In-Order Traversal recursive vs iterative approach',
        'Understand AVL Tree height balancing factor rule'
      ],
      durationHours: 2,
      completed: false
    },
    {
      dayNumber: 4,
      date: 'Day 4',
      topic: 'Graphs & BFS vs DFS',
      tasks: [
        'Represent graphs using Adjacency Matrix vs Adjacency List',
        'Trace Queue-based BFS and Stack/Recursion-based DFS',
        'Solve Shortest Path problem using BFS on unweighted graph'
      ],
      durationHours: 2,
      completed: false
    },
    {
      dayNumber: 5,
      date: 'Day 5',
      topic: 'Mock Exam & Flashcard Blitz',
      tasks: [
        'Complete timed 45-minute practice quiz',
        'Review incorrect responses with StudyBridge AI Chat',
        'Final formula & key term rapid review'
      ],
      durationHours: 2,
      completed: false
    }
  ],
  createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString()
};
