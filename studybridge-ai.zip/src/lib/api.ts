/**
 * Helper to safely fetch JSON from API routes.
 * Prevents "Unexpected token '<', '<!doctype ...'" crashes when endpoints return HTML fallback.
 */
export async function safeFetchJson<T = any>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  const contentType = response.headers.get('content-type') || '';

  if (contentType.includes('application/json')) {
    return await response.json();
  }

  // Handle HTML or non-JSON response gracefully
  const rawText = await response.text();
  console.warn(`[API] Endpoint ${url} returned non-JSON content-type "${contentType}" (${response.status})`);
  
  throw new Error(`Server returned non-JSON response (${response.status}). ${rawText.slice(0, 100)}`);
}
