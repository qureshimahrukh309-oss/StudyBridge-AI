export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

export interface Course {
  id: string;
  userId: string;
  title: string;
  code: string;
  instructor: string;
  color: string;
  schedule: string;
  description?: string;
  createdAt?: string;
}

export type TaskPriority = 'low' | 'medium' | 'high';
export type TaskStatus = 'todo' | 'in-progress' | 'completed';

export interface Task {
  id: string;
  userId: string;
  courseId: string;
  title: string;
  dueDate: string;
  priority: TaskPriority;
  status: TaskStatus;
  description?: string;
  createdAt?: string;
}

export interface Note {
  id: string;
  userId: string;
  courseId: string;
  title: string;
  fileName: string;
  fileSize: number;
  extractedText: string;
  summary: string;
  keyTerms?: string[];
  createdAt?: string;
}

export interface StudyDaySchedule {
  dayNumber: number;
  date: string;
  topic: string;
  tasks: string[];
  durationHours: number;
  completed?: boolean;
}

export interface StudyPlan {
  id: string;
  userId: string;
  courseId: string;
  courseTitle: string;
  title: string;
  targetDate: string;
  hoursPerDay: number;
  schedule: StudyDaySchedule[];
  summaryOverview: string;
  createdAt?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  sources?: string[];
}

export interface ChatSession {
  id: string;
  userId: string;
  noteId?: string;
  courseId?: string;
  title: string;
  messages: ChatMessage[];
  createdAt?: string;
}
