import express from "express";
import path from "path";
import http from "http";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { createRequire } from "module";

const require = createRequire(import.meta.url);

async function extractPdfFromBuffer(buffer: Buffer): Promise<string> {
  try {
    const pdfModule = require("pdf-parse");
    if (typeof pdfModule === "function") {
      const parsed = await pdfModule(buffer);
      return parsed.text || "";
    }
    if (pdfModule && pdfModule.PDFParse) {
      const parser = new pdfModule.PDFParse({ data: buffer });
      if (typeof parser.getText === "function") {
        const textRes = await parser.getText();
        return typeof textRes === "string" ? textRes : (textRes?.text || "");
      }
    }
  } catch (err) {
    console.warn("PDF extraction helper warning:", err);
  }
  return "";
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);
  const PORT = 3000;

  // Middleware for parsing JSON & URL encoded payloads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Helper lazy getter for Gemini AI SDK
  const getGenAI = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not configured.");
    }
    return new GoogleGenAI({ apiKey });
  };

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", service: "StudyBridge AI API" });
  });

  // API Endpoint: Parse PDF and extract structured text + AI summary
  app.post("/api/pdf-extract", async (req, res) => {
    try {
      const { fileBase64, fileName, textContent } = req.body;
      let extractedText = textContent || "";

      if (fileBase64 && !extractedText) {
        try {
          const base64Data = fileBase64.replace(/^data:application\/pdf;base64,/, "").replace(/^data:.*?;base64,/, "");
          const buffer = Buffer.from(base64Data, "base64");
          extractedText = await extractPdfFromBuffer(buffer);
        } catch (pdfErr) {
          console.warn("pdfParse warning, falling back to direct AI or raw text parsing:", pdfErr);
        }
      }

      let resultData: any = null;

      try {
        const ai = getGenAI();

        let prompt = `You are StudyBridge AI's lead study content processor.
Analyze the following study material/note titled "${fileName || 'Document'}".

Raw Content:
${(extractedText || "Uploaded document").slice(0, 15000)}

Respond ONLY with a valid JSON object matching this schema:
{
  "title": "Clean concise document title",
  "summary": "3-4 sentence comprehensive summary of core concepts covered.",
  "keyTerms": ["Term 1: Definition", "Term 2: Definition", "Term 3: Definition", "Term 4: Definition", "Term 5: Definition"],
  "extractedText": "The clean formatted main text content or key excerpts"
}`;

        let aiResponse;
        if (fileBase64 && extractedText.length < 50) {
          const cleanBase64 = fileBase64.replace(/^data:.*?;base64,/, "");
          aiResponse = await ai.models.generateContent({
            model: "gemini-3.6-flash",
            contents: [
              {
                inlineData: {
                  data: cleanBase64,
                  mimeType: "application/pdf"
                }
              },
              prompt
            ],
            config: {
              responseMimeType: "application/json"
            }
          });
        } else {
          aiResponse = await ai.models.generateContent({
            model: "gemini-3.6-flash",
            contents: prompt,
            config: {
              responseMimeType: "application/json"
            }
          });
        }

        const rawJson = aiResponse.text || "{}";
        resultData = JSON.parse(rawJson);
      } catch (aiErr: any) {
        console.warn("Gemini AI service unavailable, using local extraction fallback:", aiErr?.message);
        const cleanTitle = (fileName || "Study Note").replace(/\.[^/.]+$/, "");
        const previewText = extractedText.trim();
        const autoSummary = previewText.length > 50
          ? `Extracted content from "${fileName}". Covers key study topics and notes.`
          : `Uploaded material "${fileName}". Select or review this note to chat with AI or generate flashcards.`;

        resultData = {
          title: cleanTitle,
          summary: autoSummary,
          keyTerms: [
            `${cleanTitle}: Main Topic`,
            "Active Recall: Test your knowledge with practice questions",
            "Concept Summary: Overview of primary definitions"
          ],
          extractedText: previewText || `Parsed study notes for ${fileName}`
        };
      }

      return res.json({
        success: true,
        title: resultData.title || fileName || "Study Note",
        summary: resultData.summary || "Summary generated successfully.",
        keyTerms: resultData.keyTerms || [],
        extractedText: resultData.extractedText || extractedText || "Text extracted successfully."
      });
    } catch (error: any) {
      console.error("PDF extraction error:", error);
      return res.status(500).json({ 
        success: false, 
        error: error.message || "Failed to process PDF note." 
      });
    }
  });

  // API Endpoint: AI Note Chat & Study Assistant
  app.post("/api/chat", async (req, res) => {
    try {
      const { noteText, noteTitle, question, history } = req.body;

      try {
        const ai = getGenAI();

        const systemPrompt = `You are StudyBridge AI — an encouraging, clear, and intelligent academic tutor.
You assist students in understanding their notes, mastering complex topics, preparing for exams, and clarifying key concepts.

Target Note Context (${noteTitle || "Study Notes"}):
"""
${(noteText || "").slice(0, 10000)}
"""

Guidelines:
1. Answer the student's question accurately using the provided note context as primary reference.
2. If helpful, provide key takeaways, bullet points, or step-by-step breakdowns.
3. Keep answers concise, highly structured, and formatted with Markdown where helpful.
4. Always be friendly and supportive.`;

        const contentsList: any[] = [];
        contentsList.push({ role: "user", parts: [{ text: systemPrompt }] });
        contentsList.push({ role: "model", parts: [{ text: `Understood! I am ready to tutor you on "${noteTitle || 'your study notes'}". What would you like to explore or learn today?` }] });

        if (Array.isArray(history)) {
          history.forEach((msg: any) => {
            contentsList.push({
              role: msg.sender === "user" ? "user" : "model",
              parts: [{ text: msg.text }]
            });
          });
        }

        contentsList.push({ role: "user", parts: [{ text: question }] });

        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: contentsList
        });

        return res.json({
          success: true,
          reply: response.text
        });
      } catch (aiErr: any) {
        console.warn("AI Chat Gemini unavailable fallback:", aiErr?.message);
        return res.json({
          success: true,
          reply: `Here is what I found regarding **"${question}"** in **${noteTitle || "your notes"}**:\n\n` +
            `• **Core Concept**: "${question}" relates directly to the key themes outlined in your study document.\n` +
            `• **Key Takeaway**: Review the primary definitions and practice active recall questions to reinforce this topic.\n\n` +
            `*(Note: Connect your GEMINI_API_KEY environment variable to enable real-time generative tutoring.)*`
        });
      }
    } catch (error: any) {
      console.error("AI Chat Error:", error);
      return res.status(500).json({ success: false, error: error.message || "Failed to process AI chat response." });
    }
  });

  // API Endpoint: AI Study Planner Generator
  app.post("/api/generate-study-plan", async (req, res) => {
    try {
      const { courseTitle, targetDate, hoursPerDay, notesContext, extraDetails } = req.body;

      try {
        const ai = getGenAI();

        const prompt = `You are an expert academic curriculum designer and study strategist for StudyBridge AI.
Generate a structured, actionable day-by-day study plan leading up to the target date.

Course/Subject: ${courseTitle || "General Study"}
Target Exam / Goal Date: ${targetDate || "2 weeks from now"}
Available Daily Study Commitment: ${hoursPerDay || 2} hours/day
Additional Notes / Context: ${notesContext || "General course revision"}
Custom Requirements: ${extraDetails || "Focus on conceptual clarity and practice questions."}

Respond ONLY with a valid JSON object matching this schema:
{
  "title": "Action Plan: ${courseTitle || "Study Plan"}",
  "summaryOverview": "A 2-3 sentence strategic breakdown of how this plan optimizes retention.",
  "schedule": [
    {
      "dayNumber": 1,
      "date": "Day 1",
      "topic": "Core Fundamentals & Concept Mapping",
      "tasks": [
        "Review key definitions and core terminology",
        "Create mind map of primary sub-topics",
        "Complete 5 active recall flashcard questions"
      ],
      "durationHours": ${hoursPerDay || 2},
      "completed": false
    }
  ]
}`;

        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json"
          }
        });

        const parsed = JSON.parse(response.text || "{}");
        return res.json({
          success: true,
          plan: parsed
        });
      } catch (aiErr: any) {
        console.warn("AI Study Planner Gemini unavailable fallback:", aiErr?.message);
        return res.json({
          success: true,
          plan: {
            title: `Action Plan: ${courseTitle || "Exam Revision"}`,
            summaryOverview: `Custom ${hoursPerDay || 2}-hour daily revision schedule designed for ${courseTitle || "your course"}. Focuses on active recall and topic mastery.`,
            schedule: [
              {
                dayNumber: 1,
                date: "Day 1",
                topic: "Foundational Concepts & Terminology",
                tasks: [
                  "Review lecture slides and key formulas/definitions",
                  "Construct a high-level topic overview chart",
                  "Complete 5 active recall flashcards"
                ],
                durationHours: hoursPerDay || 2,
                completed: false
              },
              {
                dayNumber: 2,
                date: "Day 2",
                topic: "In-Depth Topic Analysis & Problem Solving",
                tasks: [
                  "Work through sample problems and past quizzes",
                  "Highlight areas requiring extra review",
                  "Summarize key insights in your own words"
                ],
                durationHours: hoursPerDay || 2,
                completed: false
              },
              {
                dayNumber: 3,
                date: "Day 3",
                topic: "Comprehensive Review & Self-Testing",
                tasks: [
                  "Simulate timed exam conditions on challenging topics",
                  "Review missed practice questions",
                  "Final review of flashcard deck"
                ],
                durationHours: hoursPerDay || 2,
                completed: false
              }
            ]
          }
        });
      }
    } catch (error: any) {
      console.error("Study Planner Error:", error);
      return res.status(500).json({ success: false, error: error.message || "Failed to generate study plan." });
    }
  });

  // Catch-all 404 for API routes to prevent falling through to SPA index.html
  app.all("/api/*", (_req, res) => {
    return res.status(404).json({ success: false, error: "API endpoint not found" });
  });

  // Global API Error Handler Middleware
  app.use("/api", (err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error("Express API error:", err);
    return res.status(err.status || 500).json({
      success: false,
      error: err.message || "An internal API error occurred."
    });
  });

  // Vite integration or static file serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: { server: httpServer } },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const serverInstance = httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`StudyBridge AI Server running on port ${PORT}`);
  });

  const shutdown = () => {
    serverInstance.close(() => {
      process.exit(0);
    });
  };

  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

startServer();
